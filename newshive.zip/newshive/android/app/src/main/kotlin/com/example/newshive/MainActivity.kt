package com.example.newshive

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
